use ipl;
show tables;

----- SUBJECTIVE QUESTIONS---------
-- 1. How does toss decision have affected the result of the match ? (which visualisations could be used to better present your answer) 
-- And is the impact limited to only specific venues?
-- QUERY --
WITH all_matches AS (
    SELECT m.venue_id,v.venue_name,m.match_winner,
	m.toss_winner,m.toss_decide,t1.team_id,t1.team_name
    FROM matches m
    JOIN team t1 ON m.team_1 = t1.team_id
    JOIN venue v ON m.venue_id = v.venue_id
UNION ALL
SELECT m.venue_id,v.venue_name,m.match_winner,
m.toss_winner,m.toss_decide,t2.team_id,t2.team_name
    FROM matches m
    JOIN team t2 ON m.team_2 = t2.team_id
    JOIN venue v ON m.venue_id = v.venue_id
),
team_stats AS (
    SELECT 
    venue_name,team_name,COUNT(*) AS total_matches,
    SUM(CASE WHEN team_id = match_winner THEN 1 ELSE 0 END) AS matches_won,
    SUM(CASE WHEN team_id = toss_winner THEN 1 ELSE 0 END) AS tosses_won,
	SUM(CASE WHEN team_id = toss_winner AND toss_decide = 1 THEN 1 ELSE 0 END) AS chose_bat,
    SUM(CASE WHEN team_id = toss_winner AND toss_decide = 2 THEN 1 ELSE 0 END) AS chose_bowl
    FROM all_matches WHERE match_winner IS NOT NULL
    GROUP BY venue_name, team_name
)
SELECT
    venue_name,team_name,total_matches,matches_won,
    ROUND(matches_won * 100.0 / total_matches, 2) AS win_percentage,tosses_won,
    ROUND(tosses_won * 100.0 / total_matches, 2) AS toss_win_percentage,chose_bat,chose_bowl
FROM team_stats
ORDER BY venue_name, win_percentage DESC;

-- 2. Suggest some of the players who would be best fit for the team?
-- QUERY--
-- (Top Batsmen)--
SELECT 
     p.Player_Id, 
     p.Player_Name,
     COUNT(DISTINCT m.Match_Id) AS total_Match,
     SUM(b.Runs_Scored) AS total_run,
    ROUND( 100 * SUM(b.Runs_Scored) / COUNT(b.Runs_Scored), 2) AS strike_rate,
    ROUND(SUM(runs_scored)/COUNT(DISTINCT m.Match_Id),2) as avg_runs
FROM ball_by_ball b
JOIN player p ON p.Player_Id = b.Striker
JOIN matches m ON m.Match_Id = b.Match_Id
GROUP BY p.Player_Name, p.Player_Id
ORDER BY total_run DESC, strike_rate DESC
LIMIT 10;
-- (Top Bowlers)--
WITH bolwer_season_wicket AS (
SELECT 
m.Season_Id,
b.Bowler,
p.Player_Name,
COUNT( DISTINCT b.Match_Id) AS total_matches,
COUNT( b.Match_Id ) as total_ball,
COUNT(w.Match_Id) as total_wicket 
FROM ball_by_ball b
LEFT JOIN wicket_taken w 
	 ON w.Match_Id = b.Match_Id 
	 AND w.Over_Id = b.Over_Id
	 AND w.Ball_Id = b.Ball_Id 
	 AND w.Innings_No = b.Innings_No
     AND w.Kind_Out != 3
LEFT JOIN player p ON p.Player_Id = b.Bowler
LEFT JOIN Matches m ON m.Match_Id = b.Match_Id
GROUP BY b.Bowler, m.Season_Id, p.Player_Name )
SELECT 
     Bowler AS Player_Id,Player_Name,
     SUM(total_matches) AS total_match,
     SUM(total_wicket) AS total_wicket,
     ROUND(SUM(total_ball) /SUM(total_wicket), 2) AS bowling_strike_rate
FROM bolwer_season_wicket
GROUP BY Bowler, Player_Name
HAVING COUNT(DISTINCT Season_Id) >= 3
ORDER BY total_wicket DESC ,total_match DESC, bowling_strike_rate
LIMIT 10;

-- 4.Which players offer versatility in their skills and can contribute effectively with both bat and ball? (can you visualize the data for the same)
-- QUERY--
SELECT
    p.Player_Name,
    SUM(CASE WHEN b.Striker = p.Player_Id THEN b.Runs_Scored ELSE 0 END) AS Total_Runs,
    COUNT(CASE WHEN b.Bowler = p.Player_Id AND w.Player_Out IS NOT NULL THEN 1 END) AS Total_Wickets
FROM player p
JOIN ball_by_ball b
    ON b.Striker = p.Player_Id OR b.Bowler = p.Player_Id
LEFT JOIN wicket_taken w 
    ON b.Match_Id = w.Match_Id 
    AND b.Over_Id = w.Over_Id 
    AND b.Ball_Id = w.Ball_Id 
    AND b.Innings_No = w.Innings_No
GROUP BY p.Player_Name
HAVING 
    SUM(CASE WHEN b.Striker = p.Player_Id THEN b.Runs_Scored ELSE 0 END) > 500
    AND COUNT(CASE WHEN b.Bowler = p.Player_Id AND w.Player_Out IS NOT NULL THEN 1 END) >= 35
ORDER BY 
    (SUM(CASE WHEN b.Striker = p.Player_Id THEN b.Runs_Scored ELSE 0 END) +
     (COUNT(CASE WHEN b.Bowler = p.Player_Id AND w.Player_Out IS NOT NULL THEN 1 END) * 20)) DESC;

-- 5.Are there players whose presence positively influences the morale and performance of the team? (justify your answer using visualisation)
-- QUERY--
WITH player_win_percentage AS (
    SELECT 
        p.Player_Id,
        p.Player_Name, 
        pm.Team_Id,
        t.Team_Name,
        COUNT(m.Match_Id) AS Total_Matches, 
        SUM(CASE WHEN m.Match_Winner = pm.Team_Id THEN 1 ELSE 0 END) AS Matches_Won,
        ROUND(
            100 * SUM(CASE WHEN m.Match_Winner = pm.Team_Id THEN 1 ELSE 0 END) 
            / COUNT(m.Match_Id), 
        2) AS win_percentage
    FROM player p
    JOIN player_match pm ON p.Player_Id = pm.Player_Id
    JOIN matches m ON pm.Match_Id = m.Match_Id
    JOIN team t ON t.Team_Id = pm.Team_Id
    WHERE m.Outcome_type = 1
    GROUP BY p.Player_Id, p.Player_Name, pm.Team_Id, t.Team_Name
    HAVING COUNT(m.Match_Id) > 10
)
SELECT 
    Player_Id,
    Player_Name,
    SUM(Total_Matches) AS Total_Matches,
    SUM(Matches_Won) AS Matches_Won,
    ROUND(AVG(win_percentage), 2) AS win_percentage
FROM player_win_percentage
GROUP BY Player_Id, Player_Name 
ORDER BY win_percentage DESC;

-- 6.What would you suggest to RCB before going to mega auction ? 
-- QUERY--
WITH rcb_matches AS (
    SELECT 
        Season_Id,
        Match_Id
    FROM matches
    WHERE Team_1 = 2 OR Team_2 = 2
),
rcb_runs AS (
    SELECT 
        m.Season_Id,
        SUM(b.Runs_Scored) AS total_runs,
        COUNT(DISTINCT b.Match_Id) AS total_matches
    FROM rcb_matches m
    JOIN ball_by_ball b ON m.Match_Id = b.Match_Id
    WHERE b.Team_Batting = 2
    GROUP BY m.Season_Id
),
rcb_bowling AS (
    SELECT 
        m.Season_Id,
        COUNT(w.Match_Id) AS total_wickets,
        COUNT(DISTINCT b.Match_Id) AS matches_bowled,
        COUNT(DISTINCT CONCAT(b.Match_Id, '-', b.Innings_No, '-', b.Over_Id)) AS total_overs,
        SUM(b.Runs_Scored) AS runs_conceded
    FROM rcb_matches m
    JOIN ball_by_ball b ON m.Match_Id = b.Match_Id
    LEFT JOIN wicket_taken w 
        ON w.Match_Id = b.Match_Id
        AND w.Innings_No = b.Innings_No
        AND w.Over_Id = b.Over_Id
        AND w.Ball_Id = b.Ball_Id
        AND w.Kind_Out NOT IN (3)  
    WHERE b.Team_Bowling = 2
    GROUP BY m.Season_Id
)
SELECT 
    r.Season_Id,
    r.total_runs,
    b.total_wickets,
    ROUND(r.total_runs / r.total_matches, 2) AS avg_runs_per_match,
    ROUND(b.total_wickets / b.matches_bowled, 2) AS avg_wickets_per_match,
    ROUND(b.runs_conceded / NULLIF(b.total_overs, 0), 2) AS economy_rate
FROM rcb_runs r
JOIN rcb_bowling b ON r.Season_Id = b.Season_Id
ORDER BY r.Season_Id;

-- 7.What do you think could be the factors contributing to the high-scoring matches and the impact on viewership and team strategies
-- QUERY--
SELECT
v.Venue_Name,
ROUND(SUM(b.Runs_Scored) * 1.0 / COUNT(b.Ball_Id), 2) AS Avg_Runs_Per_Ball
FROM Ball_by_Ball b
JOIN Matches m ON b.Match_Id = m.Match_Id
JOIN Venue v ON m.Venue_Id = v.Venue_Id                  
GROUP BY v.Venue_Name
ORDER BY Avg_Runs_Per_Ball DESC;

-- 8.Analyze the impact of home ground advantage on team performance and identify strategies to maximize this advantage for RCB.
-- QUERY--
SELECT 
    t.Team_Name,
    v.Venue_Name,
    SUM(CASE WHEN m.Match_Winner = t.Team_Id THEN 1 ELSE 0 END) AS Wins,
    COUNT(m.Match_Id) AS Total_Matches,
    ROUND(100.0 * SUM(CASE WHEN m.Match_Winner = t.Team_Id THEN 1 ELSE 0 END) / COUNT(m.Match_Id), 2) AS Win_Percentage,
    CASE 
        WHEN v.Venue_Name LIKE '%Chinnaswamy%' THEN 'Home'
        ELSE 'Away'
    END AS Match_Type
FROM matches m
JOIN team t ON (m.Team_1 = t.Team_Id OR m.Team_2 = t.Team_Id)
JOIN venue v ON m.Venue_Id = v.Venue_Id
WHERE t.Team_Name = 'Royal Challengers Bangalore'
GROUP BY t.Team_Name, v.Venue_Name, Match_Type
ORDER BY Match_Type, Win_Percentage DESC;

-- 9.Come up with a visual and analytical analysis with the RCB past seasons performance and potential reasons for them not winning a trophy.
-- QUERY--
-- (Top Batsmen)--
SELECT 
     b.Striker as Player_Id, 
     p.Player_Name,
     SUM(b.Runs_Scored) AS total_run
    FROM ball_by_ball b
JOIN matches m ON b.Match_Id = m.Match_Id
JOIN player p ON  b.Striker = p.Player_Id
where b.team_batting=2
GROUP BY p.Player_Name, b.Striker
ORDER BY total_run DESC
LIMIT 10;
-- Top Bowling performance--
with cte as(
SELECT 
    b.Bowler AS Bowler_Id,
    COUNT(w.Player_Out) AS total_wickets
FROM wicket_taken w
JOIN ball_by_ball b 
    ON w.Match_Id = b.Match_Id
    AND w.Innings_No = b.Innings_No
    AND w.Over_Id = b.Over_Id
    AND w.Ball_Id = b.Ball_Id
    where team_Bowling =2
    group by b.Bowler
    )
    select Bowler_Id,p.Player_Name, total_wickets
    from cte c join player p
    on c.Bowler_Id = p.player_Id
    order by total_wickets desc limit 10;
-- 11. In the "Match" table, some entries in the "Opponent_Team" column are incorrectly spelled as "Delhi_Capitals" instead of "Delhi_Daredevils". Write an SQL query to replace all occurrences of "Delhi_Capitals" with "Delhi_Daredevils".
-- QUERY--
UPDATE Matches
SET Opponent_Team="Delhi_Daredevils"
WHERE Opponent_Team="Delhi_Capitals";




