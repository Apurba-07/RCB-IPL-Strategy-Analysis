use ipl;
show tables;

----- OBJECTIVE QUESTIONS---------
-- 1.List the different dtypes of columns in table “ball_by_ball” (using information schema)
----- QUERY----
SELECT COLUMN_NAME,DATA_TYPE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'Ball_by_Ball';

-- 2.What is the total number of run scored in 1st season by RCB (bonus : also include the extra runs using the extra runs table)
-- QUERY--
WITH cte_runs AS (
    SELECT 
        COALESCE(b.Runs_Scored, 0) AS batsman_runs,
        COALESCE(e.Extra_Runs, 0) AS extra_runs
    FROM ball_by_ball b
    JOIN matches m 
        ON b.Match_Id = m.Match_Id
    LEFT JOIN extra_runs e 
        ON b.Match_Id = e.Match_Id
       AND b.Innings_No = e.Innings_No
       AND b.Over_Id = e.Over_Id
       AND b.Ball_Id = e.Ball_Id
    WHERE m.Season_Id = 6
      AND b.Team_Batting = 2   
)
SELECT 
    SUM(batsman_runs) AS total_runs,
    SUM(extra_runs) AS total_extra_runs,
    SUM(batsman_runs + extra_runs) AS total_runs_with_extras
FROM cte_runs;

-- 3.How many players were more than age of 25 during 2014 ?
-- QUERY--
with 2014_matches as(
select Match_Id from matches
where YEAR(Match_Date) = 2014
),
all_players_2014 as(
select Player_Id from player_match
where Match_Id IN(select Match_Id from 2014_matches)
),
first_match_2014 as(
select min(Match_Date) as first_match from matches
where year(Match_Date) = 2014
),
players_age as(
select a.Player_Id,Player_Name,YEAR(DOB)  as Date_of_year,
TIMESTAMPDIFF(YEAR,DOB,'2014-01-01') AS current_age
from all_players_2014 a
join player p
on a.Player_Id = p.Player_Id
)
select count(distinct player_id) as players_age_above_25
from players_age where current_age > 25;

-- 4.How many matches did RCB win in season 2013 ? 
-- QUERY--
SELECT 
     COUNT(*) AS total_match,
     SUM(CASE WHEN Match_Winner = 2 THEN 1 ELSE 0 END) AS total_winning_match
FROM matches 
WHERE YEAR(Match_Date) = 2013 
  AND (Team_1 = 2 OR Team_2 = 2);
  
  -- 5. List top 10 players according to their strike rate in last 4 seasons.
  -- QUERY--
  WITH last_4_seasons AS (
    SELECT Season_Id FROM season
    ORDER BY Season_Year DESC LIMIT 4
),
recent_matches AS (
    SELECT Match_Id FROM matches
    WHERE Season_Id IN (SELECT Season_Id FROM last_4_seasons)
),
player_stats AS (
    SELECT p.Player_Id, p.Player_Name,
	SUM(b.Runs_Scored) AS total_runs, COUNT(b.Ball_Id) AS balls_faced
    FROM ball_by_ball b
    JOIN player p ON p.Player_Id = b.Striker
    WHERE b.Match_Id IN (SELECT Match_Id FROM recent_matches)
    GROUP BY p.Player_Id, p.Player_Name
)
SELECT 
    Player_Id, Player_Name,total_runs,balls_faced,
    ROUND(100.0 * total_runs / balls_faced, 2) AS strike_rate
FROM player_stats WHERE balls_faced > 0
ORDER BY strike_rate DESC LIMIT 10;

-- 6. What is the average runs scored by each batsman considering all the seasons?
-- QUERY--
WITH grouped_data AS (
SELECT  
 b.Match_Id, p.Player_Name, p.Player_Id,
 SUM(b.Runs_Scored) AS batsman_total_score
FROM player p
JOIN ball_by_ball b ON b.Striker = p.Player_Id
AND NOT EXISTS (
    SELECT 1 FROM extra_runs e
    WHERE b.Match_Id = e.Match_Id
	AND b.Over_Id = e.Over_Id
	AND b.Ball_Id = e.Ball_Id
	AND e.Extra_Type_Id NOT IN(1,3)
	AND b.Innings_No = e.Innings_No
) 
GROUP BY p.Player_Id, p.Player_Name, b.Match_Id)
SELECT Player_Id,Player_Name, 
    ROUND(AVG(batsman_total_score), 2) AS avg_score 
    FROM grouped_data GROUP BY Player_Id, Player_Name
	HAVING SUM(batsman_total_score) > 500
    ORDER BY avg_score DESC;
    
-- 7. What are the average wickets taken by each bowler considering all the seasons?
-- QUERY--
with bowler_wickets_per_match AS (
    select b.Match_Id, p.Player_Id,p.Player_Name,
	COUNT(w.Player_Out) AS wickets_in_match
    FROM ball_by_ball b
    JOIN wicket_taken w 
    on b.Match_Id = w.Match_Id
        AND b.Innings_No = w.Innings_No
        AND b.Over_Id = w.Over_Id
        AND b.Ball_Id = w.Ball_Id
	JOIN player p ON b.Bowler = p.Player_Id
    JOIN matches m ON b.Match_Id = m.Match_Id   
	WHERE w.Kind_Out <> 3
    GROUP BY p.Player_Id, p.Player_Name, b.Match_Id
)
SELECT Player_Id, Player_Name,
ROUND(AVG(wickets_in_match), 2) AS avg_wicket
FROM bowler_wickets_per_match  
GROUP BY Player_Id, Player_Name
ORDER BY avg_wicket DESC ;

-- 8. List all the players who have average runs scored greater than overall average and who have taken wickets greater than overall average
-- QUERY--
WITH BattingStats AS (
    SELECT b.Striker AS Player_Id,
	SUM(b.Runs_Scored) AS Total_Runs,
	COUNT(DISTINCT b.Match_Id, b.Innings_No) AS Innings_Batted,
	ROUND(SUM(b.Runs_Scored) / COUNT(DISTINCT b.Match_Id, b.Innings_No), 2) AS Avg_Runs
    FROM Ball_by_Ball b
    GROUP BY b.Striker
    HAVING Innings_Batted > 0
),
WicketStats AS (
    SELECT b.Bowler AS Player_Id,COUNT(*) AS Total_Wickets
    FROM Wicket_Taken wt
    JOIN Ball_by_Ball b 
	   ON wt.Match_Id = b.Match_Id 
       AND wt.Over_Id = b.Over_Id 
       AND wt.Ball_Id = b.Ball_Id 
       AND wt.Innings_No = b.Innings_No
    GROUP BY b.Bowler
),
OverallAverages AS (
    SELECT 
        (SELECT ROUND(AVG(Avg_Runs), 2) FROM BattingStats) AS Overall_Batting_Avg,
        (SELECT ROUND(AVG(Total_Wickets), 2) FROM WicketStats) AS Overall_Wicket_Avg
),
QualifiedPlayers AS (
    SELECT bs.Player_Id,bs.Avg_Runs,ws.Total_Wickets
    FROM BattingStats bs
    JOIN WicketStats ws ON bs.Player_Id = ws.Player_Id
)
SELECT 
p.Player_Name,qp.Avg_Runs,qp.Total_Wickets
FROM QualifiedPlayers qp
JOIN Player p ON p.Player_Id = qp.Player_Id
CROSS JOIN OverallAverages oa
WHERE qp.Avg_Runs > oa.Overall_Batting_Avg
AND qp.Total_Wickets > oa.Overall_Wicket_Avg
ORDER BY qp.Avg_Runs DESC, qp.Total_Wickets DESC;


-- 9. Create a table rcb_record table that shows the wins and losses of RCB in an individual venue.
-- QUERY--
SELECT 
  v.Venue_Id,
  v.Venue_Name,
  COUNT(m.Match_Id) AS total_matches,
  
  SUM(CASE WHEN m.Match_Winner = 2 THEN 1 ELSE 0 END) AS total_win,
  SUM(CASE WHEN m.Match_Winner != 2 AND m.Match_Winner IS NOT NULL THEN 1 ELSE 0 END) AS total_loss,
  SUM(CASE WHEN m.Match_Winner IS NULL THEN 1 ELSE 0 END) AS no_result_draw
  
FROM venue v
JOIN matches m 
  ON m.Venue_Id = v.Venue_Id
WHERE (m.Team_1 = 2 OR m.Team_2 = 2)
GROUP BY v.Venue_Id, v.Venue_Name
ORDER BY total_win DESC;

-- 10. What is the impact of bowling style on wickets taken?
-- QUERY--
with each_bowler_wickets as(
select Bowler,count(Bowler) as no_of_wickets from wicket_taken w
join ball_by_ball b
on w.Match_Id = b.match_Id and w.Over_Id=b.Over_Id and w.Ball_Id=b.Ball_Id and
w.Innings_No = b.Innings_No
Group by Bowler
)
select b.Bowling_skill,count(Bowler) as no_of_bowlers,sum(no_of_wickets) as skill_wise_wickets,
ROUND(sum(no_of_wickets)/count(Bowler),2) as average_wickets from each_bowler_wickets e
join player p
on p.Player_Id =e.Bowler
join bowling_style b
on p.Bowling_skill=b.Bowling_Id
group by b.Bowling_skill;

-- 11. Write the SQL query to provide a status of whether the performance of the team is better than the previous year's performance on the basis of the number of runs scored by the team in the season and the number of wickets taken?
-- QUERY --
WITH runs_season AS (
    SELECT m.Season_Id,b.Team_Batting AS Team_Id,
	SUM(b.Runs_Scored) AS total_runs
    FROM ball_by_ball b
    JOIN matches m ON m.Match_Id = b.Match_Id
    GROUP BY m.Season_Id, b.Team_Batting
),
wickets_season AS (
    SELECT m.Season_Id,b.Team_Bowling AS Team_Id,
	COUNT(w.Player_Out) AS total_wickets
    FROM wicket_taken w
    JOIN ball_by_ball b 
	ON w.Match_Id = b.Match_Id
	AND w.Innings_No = b.Innings_No
	AND w.Over_Id = b.Over_Id
	AND w.Ball_Id = b.Ball_Id
    JOIN matches m ON m.Match_Id = b.Match_Id
    WHERE w.Kind_Out <> 3      
    GROUP BY m.Season_Id, b.Team_Bowling
),
combined AS (
    SELECT
        r.Season_Id,r.Team_Id,
        r.total_runs,w.total_wickets,
        LAG(r.total_runs) OVER (PARTITION BY r.Team_Id ORDER BY r.Season_Id) AS prev_runs,
        LAG(w.total_wickets) OVER (PARTITION BY w.Team_Id ORDER BY w.Season_Id) AS prev_wickets
    FROM runs_season r
    JOIN wickets_season w ON r.Team_Id = w.Team_Id
	AND r.Season_Id = w.Season_Id
)
SELECT 
    c.Season_Id,t.Team_Name,
    c.total_runs,c.prev_runs,
    CASE 
        WHEN c.total_runs > c.prev_runs THEN 'Good Performance'
        WHEN c.total_runs = c.prev_runs THEN 'Same Performance'
        ELSE 'Bad Performance'
    END AS batting_status,
    c.total_wickets,
    c.prev_wickets,
    CASE 
        WHEN c.total_wickets > c.prev_wickets THEN 'Good Performance'
        WHEN c.total_wickets = c.prev_wickets THEN 'Same Performance'
        ELSE 'Bad Performance'
    END AS bowling_status
FROM combined c
JOIN team t ON t.Team_Id = c.Team_Id
WHERE c.prev_runs IS NOT NULL
ORDER BY c.Season_Id;

-- 12.Can you derive more KPIs for the team strategy?
-- QUERY--
select p.Player_Name,
ROUND(sum(case when b.Runs_Scored IN(4,6) then 1 else 0 end) * 100.0 / count(*),2) as Boundary_Percentage
from ball_by_ball b
join player p on b.Striker = p.Player_Id
where b.Team_Batting =(
    select Team_Id
    from team
    where team_Id = 2
    )
    group by p.Player_Name;
 -- Home vs Away Performance--
 select 
 CASE WHEN v.Venue_Name='M Chinnaswamy Stadium' THEN 'Home'
      ELSE 'Away'
END AS Location,
COUNT(*) AS Matches_Played,
SUM(CASE WHEN Match_Winner = t.Team_Id THEN 1 ELSE 0 END) AS Matches_Won,
ROUND(SUM(CASE WHEN Match_Winner = t.Team_Id THEN 1 ELSE 0 END)*100.0/COUNT(*),2) AS Win_Percentage
from matches m
join venue v on m.Venue_Id = v.Venue_Id
join team t on t.Team_Name = 'Royal Challengers Bangalore'
where t.Team_Id in(m.Team_1,m.Team_2)
GROUP BY Location;
-- Bowling Style Effectiveness--
select bs.Bowling_skill,
count(*) as Deliveries,
SUM(CASE WHEN w.Player_Out IS NOT NULL THEN 1 ELSE 0 END) AS Wickets,
ROUND(SUM(b.Runs_Scored * 1.0)/count(*),2) AS Economy_Rate
from ball_by_ball b
join player p on b.Bowler = p.Player_Id
join bowling_style bs on p.Bowling_skill = bs.Bowling_Id
LEFT JOIN wicket_taken w on (b.Match_Id = w.Match_Id and b.Over_Id = w.Over_Id
 and b.Ball_Id = w.Ball_Id and b.Innings_No = w.Innings_No )
 where b.Team_Bowling =(select Team_Id from team where Team_name ='Royal Challengers Bangalore')
 group by bs.Bowling_skill
 order by Economy_Rate;
-- Dot Ball Percentage--
select p.Player_Name,
ROUND(SUM(CASE WHEN b.Runs_Scored = 0 THEN 1 ELSE 0 END) *100.0/COUNT(*),2) AS Dot_Ball_Percentage
from ball_by_ball b
join player p on b.Bowler = p.Player_Id
where b.Team_Bowling = (select Team_Id from team where Team_Name ='Royal Challengers Bangalore')
group by p.Player_Name; 

-- 13.Using SQL, write a query to find out the average wickets taken by each bowler in each venue. Also, rank the gender according to the average value.
-- QUERY--
WITH each_bowler_wickets AS (
    SELECT 
        w.Match_Id,b.Bowler,
        COUNT(*) AS wickets_in_match
    FROM wicket_taken w
    JOIN ball_by_ball b
        ON w.Match_Id = b.Match_Id
       AND w.Over_Id = b.Over_Id
       AND w.Ball_Id = b.Ball_Id
       AND w.Innings_No = b.Innings_No
    GROUP BY w.Match_Id, b.Bowler
),
venue_wickets AS (
    SELECT e.Bowler,m.Venue_Id,v.Venue_Name,
	AVG(e.wickets_in_match) AS avg_wickets_per_match
    FROM each_bowler_wickets e
    JOIN matches m ON e.Match_Id = m.Match_Id
    JOIN venue v ON v.Venue_Id = m.Venue_Id
    GROUP BY e.Bowler, m.Venue_Id, v.Venue_Name
)
SELECT 
    v.Venue_Id,
    v.Venue_Name,
    p.Player_Name,
    ROUND(v.avg_wickets_per_match, 2) AS average_wickets,
    RANK() OVER (PARTITION BY v.Venue_Id ORDER BY v.avg_wickets_per_match DESC) AS rank_in_venue
FROM venue_wickets v
JOIN player p ON v.Bowler = p.Player_Id
ORDER BY v.Venue_Name, rank_in_venue;

-- 14. Which of the given players have consistently performed well in past seasons? (will you use any visualization to solve the problem)
-- QUERY--
-- consistent batsmen--
with batting_performance as (
select Striker,Player_Name,
sum(runs_scored) as total_runs,
count(distinct Match_Id) as Innings_played,
ROUND(sum(runs_scored)/count(distinct Match_Id),2) as average_runs
from ball_by_ball b
join player p
on b.striker = p.Player_Id
group by striker
)
select * from batting_performance 
where total_runs>1500 and Innings_played>40;
-- -- consistent bowler--
WITH cte AS (
    SELECT 
        DISTINCT b.Bowler AS Bowler_Id, p.Player_Name,
        COUNT(w.Player_Out) AS Total_Wickets,
        COUNT(DISTINCT b.Match_Id) AS Innings_Played,
        ROUND((COUNT(w.Player_Out) / COUNT(DISTINCT b.Match_Id)),2) AS Avg_Wickets_Taken
    FROM ball_by_ball b
    JOIN player p ON b.Bowler = p.Player_Id
    JOIN wicket_taken w ON b.Match_Id = w.Match_Id
	AND b.Over_Id = w.Over_Id
	AND b.Ball_Id = w.Ball_Id
	AND b.Innings_No = w.Innings_No
    JOIN matches m ON b.Match_Id = m.Match_Id
    GROUP BY b.Bowler, p.Player_Name
)
SELECT * FROM cte
WHERE Total_Wickets > 55 AND Innings_Played > 30
ORDER BY Total_Wickets DESC, Innings_Played DESC;
-- Season wise player score--
SELECT
p.Player_Name,
s.Season_Year,
SUM(b.Runs_Scored) AS Total_Runs
FROM
Ball_by_Ball b
JOIN Matches m ON b.Match_Id = m.Match_Id
JOIN Season s ON m.Season_Id = s.Season_Id
JOIN Player p ON b.Striker = p.Player_Id
GROUP BY
p.Player_Name, s.Season_Year
ORDER BY
p.Player_Name, s.Season_Year;

-- 15. Are there players whose performance is more suited to specific venues or conditions? (how would you present this using charts?)
-- QUERY--
SELECT 
p.Player_Name, v.Venue_Name, 
SUM(b.Runs_Scored) AS total_runs 
FROM ball_by_ball b 
JOIN matches m ON b.Match_Id = m.Match_Id 
JOIN venue v ON m.Venue_Id = v.Venue_Id 
JOIN player p ON b.Striker = p.Player_Id
GROUP BY p.Player_Name, v.Venue_Name 
order by total_runs desc;

-- For Bowlers (Wickets per Venue)--
SELECT
p.Player_Name,
v.Venue_Name,
COUNT(w.Player_Out) AS Total_Wickets
FROM
Ball_by_Ball b
JOIN Wicket_Taken w ON b.Match_Id = w.Match_Id
AND b.Over_Id = w.Over_Id
AND b.Ball_Id = w.Ball_Id
AND b.Innings_No = w.Innings_No
JOIN Matches m ON b.Match_Id = m.Match_Id
JOIN Venue v ON m.Venue_Id = v.Venue_Id
JOIN Player p ON b.Bowler = p.Player_Id
GROUP BY
p.Player_Name, v.Venue_Name
order by total_wickets desc;

